public class Main {
    public static void main(String[] args) {

    //    Ticket newTicket = new Ticket("24124", "GJS-3253", "White", "ANY", "ABABA", "Birdy", "")






    }
}