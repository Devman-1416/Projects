public class Ticket {

    private Vehicle oneVehicle;
    private Owner oneOwner;
    private Officer oneOfficer;
    private Violation oneViolation;

    private String date;
    private String ticketNumber;
    private String time;
    private String meterNumber;

    // CONSTRUCTOR

    public Ticket(String vinNumber, String licensePlate, String carColor, String model, String make,
                  String ownersName, String ownersAddress,
                  String name, int badgeNumber,
                  String violationType, String description, double fee,
                  String date, String time, String meterNumber, String ticketNumber){

        this.oneVehicle = new Vehicle(vinNumber, licensePlate, carColor, model, make);
        this.oneOwner = new Owner(ownersName, ownersAddress);
        this.oneOfficer = new Officer(name, badgeNumber);
        this.oneViolation = new Violation(violationType, description, fee);

        this.date = date;
        this.ticketNumber = ticketNumber;
        this.time = time;
        this.meterNumber = meterNumber;
    }


























}
